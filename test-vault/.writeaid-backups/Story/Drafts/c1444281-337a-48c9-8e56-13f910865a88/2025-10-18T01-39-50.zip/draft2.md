---
draft: Draft 2
project: Story
created: 2025-10-15T21:11:09.599Z
id: c1444281-337a-48c9-8e56-13f910865a88
---

# The Rule

This is a copy of my tremendous novel. I do no want to lose it!
